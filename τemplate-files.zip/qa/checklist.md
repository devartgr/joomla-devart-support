# {{PRODUCT_NAME}} QA Checklist

## Installation

- [ ] Clean installation succeeds
- [ ] Update installation succeeds
- [ ] No missing language-file warning
- [ ] No duplicate administrator menu error
- [ ] Package and every declared extension are installed
- [ ] Plugins and modules have the expected enabled state
- [ ] No undeclared extension is installed

## Administrator

- [ ] Every declared administrator view opens
- [ ] Configuration saves and reloads correctly
- [ ] Permissions are enforced for every protected action
- [ ] User input is validated and output is escaped
- [ ] Extension status is reported correctly

## Frontend

- [ ] Expected frontend output is rendered
- [ ] Enabled and disabled states behave correctly
- [ ] Invalid or missing configuration fails safely
- [ ] JavaScript has no console errors
- [ ] Browser behavior works without jQuery unless explicitly required

## Performance and Cache

- [ ] Joomla cache OFF
- [ ] Joomla cache ON
- [ ] Functional behavior works behind full-page cache
- [ ] Functional behavior works behind Cloudflare
- [ ] No unnecessary database queries, filesystem scans, or remote requests
- [ ] Shared-hosting and high-traffic behavior remains safe

## Multilingual

Supported languages under test:

- {{SUPPORTED_LANGUAGES}}

- [ ] Every packaged administrator and frontend language loads
- [ ] Language switching uses the matching translations
- [ ] Missing optional translations fall back safely

## PHP Compatibility Matrix

Validate in the target Joomla hosting environment, not only on the CLI used
for repository scripts.

| Check | Expected |
|-------|----------|
| PHP minimum | `8.3.0` in every package and extension manifest |
| Web SAPI PHP version | Meets or exceeds manifest `php_minimum` |
| Required extensions | `json`, `mbstring`, `dom`, `simplexml`, `zlib` |
| Database driver | `mysqli` or `pdo_mysql` |
| Recommended extensions | `curl`, `gd`, `openssl`, `xml`, `zip`, `opcache` |

- [ ] Web-server PHP version meets manifest minimum
- [ ] Required PHP extensions are available in the web SAPI
- [ ] At least one supported MySQL driver is available in the web SAPI
- [ ] Recommended PHP extensions are available or their absence is accepted
- [ ] CLI validation result does not replace Joomla runtime QA

## Product-Specific QA

{{PRODUCT_QA_CHECKS}}

## Package Quality

- [ ] PHP syntax validation
- [ ] XML validation
- [ ] Manifest references validation
- [ ] Version consistency
- [ ] PHP minimum is `8.3.0` in every package and extension manifest
- [ ] Every manifest has a valid `creationDate` in `YYYY-MM-DD` format
- [ ] Package inventory contains only declared extensions
- [ ] Inner ZIP paths match the package manifest folder
- [ ] SHA-256 generated
