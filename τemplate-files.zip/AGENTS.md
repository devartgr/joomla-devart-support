# DevArt Repository Standards

## Project

This repository is part of the DevArt Joomla extension family.

Read this file before making any change.

---

# Communication

- Always communicate with the user in **Greek**, unless the user explicitly requests another language.
- Source code, comments, manifests, README, CHANGELOG and all repository documentation remain in **English**.

---

# Supported Platform

- Joomla 6+
- PHP 8.3+
- Modern MariaDB/MySQL
- No Joomla 3/4/5 compatibility
- No PHP 7.x or PHP 8.0–8.2 compatibility
- No backward compatibility.
- No deprecated Joomla APIs.

---

# Core Principles

Always prioritize:

1. Stability
2. Simplicity
3. Security
4. Joomla-native architecture
5. Update safety
6. Performance
7. Maintainability

Prefer the **smallest safe solution**.

Never introduce unnecessary complexity.

---

# Repository Philosophy

The repository is the **single source of truth**.

All development happens only inside:

```
source/
```

Never use:

- builds/
- releases/
- archive/
- extracted ZIP packages

for development.

Generated packages are disposable.

If a generated package differs from the repository,
the repository is always considered correct.

---

# Repository Structure

```
source/
builds/
releases/
archive/
docs/
qa/
scripts/
```

Only `source/` contains editable source code.

---

# Working Method

Before every task:

1. Read `AGENTS.md`.
2. Read `PROJECT_STATUS.md`.
3. Read the relevant documentation under `docs/`.
4. Inspect the existing implementation.
5. Explain the planned change.
6. Identify the files that will be modified.

Rules:

- Never modify unrelated files.
- Never perform unnecessary refactoring.
- Always implement the smallest safe change.
- If something is unclear, ask before implementing.

---

# Standard Development Cycle

Every milestone follows exactly this workflow:

```
Read
↓

Plan
↓

Implement

↓

Validate

↓

Build installable package

↓

STOP

↓

User performs Joomla QA

↓

If successful

↓

Update PROJECT_STATUS.md

↓

Next milestone
```

One installable package = One milestone.

Never continue automatically to the next milestone.

---

# Mandatory QA Question

If the current task generates a new installable package,
the agent MUST stop after the build.

Before continuing, always ask:

> Έγινε η δοκιμή στο Joomla;
> Είναι όλα σωστά ώστε να κλείσουμε αυτό το milestone και να ενημερώσω το PROJECT_STATUS.md;

Do not skip this question.

Do not continue with another milestone until the user answers.

---

# PROJECT_STATUS.md

`PROJECT_STATUS.md` is the operational summary of the repository.

Read it before every task.

Update it **only** after the user explicitly confirms that the generated package was successfully installed and tested in Joomla.

Never update it:

- after planning
- after editing code
- after validation only
- after building only

Record only verified information.

Never invent:

- versions
- build numbers
- release status
- verification results

Keep the file short and practical.

---

# Validation

Before building:

- PHP syntax
- XML validation
- Manifest validation
- Manifest references
- Version consistency
- Diff review

Then:

- Build installable package
- Generate SHA-256

Never claim Joomla compatibility without a real Joomla installation test.

---

# Coding Rules

- Use Joomla-native APIs.
- Use Dependency Injection where appropriate.
- Use WebAssetManager where appropriate.
- Use typed PHP.
- Use strict types.
- Avoid global state.
- Avoid unnecessary dependencies.
- Prefer CSS over JavaScript whenever possible.
- Prefer native JavaScript.
- Never introduce jQuery or external frontend frameworks unless explicitly required.

---

# Performance

Design for:

- very large Joomla websites
- high traffic
- Cloudflare
- Full Page Cache
- shared hosting
- enterprise servers

Avoid:

- unnecessary database queries
- unnecessary filesystem scans
- unnecessary remote requests

---

# Security

Never expose filesystem paths.

Always use:

Controller → Service → Storage

Always enforce access before serving content.

Validate every input.

Escape every output.

---

# UI

Use Joomla-native administrator UI.

Use the standard DevArt themes:

- Red
- Orange
- Blue
- Green
- Yellow
- Gray
- Dark

Only the active submenu uses the DevArt active color.

---

# Build Rules

All generated packages must:

- install correctly
- update correctly
- include every required extension
- generate SHA-256
- never overwrite an existing build

---

# Repository Infrastructure Changes

Changes affecting:

- scripts/
- manifests under `source/`
- repository structure
- packaging
- validation

must always be:

- validated
- built

A Joomla QA is required only if a new installable package is generated.

Do not update `PROJECT_STATUS.md`
until the user confirms successful Joomla testing.

---

# Documentation-only Changes

If a task modifies only:

- AGENTS.md
- PROJECT_STATUS.md
- README.md
- CHANGELOG.md
- docs/
- qa/

and does not modify:

- source/
- manifests under `source/`
- scripts/
- generated package contents

then:

- Do not run validation unless explicitly requested.
- Do not build a new installable package.
- Do not request Joomla QA.
- Review the documentation changes and stop.

If a new installable package is generated,
this workflow no longer applies.

Follow the Standard Development Cycle.

---

# Decision Rules

If something is unclear:

- Ask.
- Do not guess.
- Do not silently change architecture.
- Do not implement assumptions.

When in doubt,
choose the simplest safe solution.

---

# Model Workflow

Primary implementation happens in this repository.

Other AI models may be used only for:

- review
- validation
- architecture discussion

unless the user explicitly requests otherwise.

---

# Project-Specific Rules

Complete these rules during product bootstrap. Do not leave this section empty in
an active product repository.

{{PROJECT_SPECIFIC_RULES}}