# Project
{{PRODUCT_NAME}} — {{PRODUCT_DESCRIPTION}}

# Current Version
Not set — template baseline awaiting product bootstrap.

# Package
{{PACKAGE_ID}}

# Extension Inventory
{{EXTENSION_IDS}}

# Repository Status
Template baseline — awaiting product bootstrap.

# Verified Package
Not verified.

# Verified SHA-256
Not verified.

# Verified Creation Date
Not verified.

# Last Completed
Template generalization to DevArt Repository Template v1.1.0.

# Current Milestone
{{CURRENT_MILESTONE}}

# Next Milestone
Bootstrap a product package manifest and extension sources, then run validation,
build, and Joomla QA.

# Pending
- Add `source/package/pkg_*.xml` and real extension sources.
- Replace documentation placeholders with product facts.
- Complete Joomla QA before recording verification here.
