# {{PRODUCT_NAME}} — Architecture

## Repository Layout

`source/` is the only development source:

- `source/package/` — outer Joomla package manifest and package language files.
- `source/extensions/component/` — component sources.
- `source/extensions/modules/` — module sources.
- `source/extensions/plugins/` — plugin sources.

Generated packages belong only under `builds/`.

## Package Composition

Package: `{{PACKAGE_ID}}`

Declared extensions:

{{EXTENSION_IDS}}

The package manifest is the source of truth for the package name, version,
inner archive names, and inner archive folder.

The build script derives the outer package filename from the package manifest
filename:

`{{PACKAGE_ID}}_v{{VERSION}}.zip`

## Product Architecture

{{ARCHITECTURE_SUMMARY}}

## Source of Truth

- Develop only in `source/`.
- Treat generated archives as disposable output.
- Keep all extension manifest versions identical to the package version.
- Keep every manifest `creationDate` in `YYYY-MM-DD` format.
- Keep every manifest `php_minimum` identical to the DevArt PHP minimum.

## Build and Validation

- `scripts/validate.php` validates manifests, references, versions, naming,
  XML, JSON, PHP syntax, PHP runtime extensions, and Joomla workspace awareness.
- `scripts/build.php` runs validation first, creates the declared inner
  extension ZIPs, the outer package, and its SHA-256 checksum.
- Build tooling does not modify `source/` and does not overwrite an existing
  build.
