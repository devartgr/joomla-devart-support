# {{PRODUCT_NAME}} — Current State

## Development Source

Current manifest version:

`{{VERSION}}`

Package:

`{{PACKAGE_ID}}`

Extensions:

{{EXTENSION_IDS}}

## Implemented Features

{{IMPLEMENTED_FEATURES}}

## Known Limitations

{{KNOWN_LIMITATIONS}}

## Pristine Template State

This repository is a generic template until product bootstrap is complete.

- `source/package/` contains no `pkg_*.xml` manifest yet.
- Extension directories contain only placeholder `.gitkeep` files.
- `php scripts/validate.php` is expected to fail with a controlled error until
  a package manifest and at least one real extension source are added.
- No Joomla QA claim should be recorded until a generated package is tested in
  a real Joomla installation.

## Repository Tooling

- Validation and build tooling follows the package manifest rather than a
  product-specific configuration file.
- Build output belongs under `builds/` and must never overwrite an existing
  build.
- The manifests require PHP `8.3.0` as the DevArt minimum.
- Joomla 6 is the current DevArt production series.
